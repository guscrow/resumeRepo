package Rello;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;

public interface ServerInterface extends Remote
{
	public User createBoard(String bname, User user) throws RemoteException;
	public User Login(String username, String password) throws RemoteException;
	public User updateBoard(User user, Board board) throws RemoteException;
	public Registry bootServer(String bindName) throws RemoteException;
	public void closeServer(Registry registry) throws RemoteException;
}
