/**
 * 
 */
package Rello;

import java.util.ArrayList; // import the ArrayList class
import java.util.Random;

import javafx.beans.property.StringProperty;

import java.util.HashMap; // import the HashMap class
import java.io.*;

/**
 * @author guscrow
 *
 */

public class Board implements Serializable
{
	/**
	 * @return the board_id
	 */
	public int getBoard_id()
	{
		return board_id;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 3781722048977288160L;
	public String Name;
	public User Owner;
	public int board_id;
	public HashMap<String, User> Members = new HashMap<String, User>();
	public ArrayList<List> Lists = new ArrayList<List>();

	/**
	 * @param name
	 */
	public Board(String name, User owner)
	{
		Name = name;
		Owner = owner;
		this.board_id = generateID();
	}
	
	
	public int generateID()
	{
		Random rand = new Random();
		int upperbound = 100;
		int int_random = rand.nextInt(upperbound);
		while (Server.getBoards().containsKey(Integer.toString(int_random)))
		{
			int_random = rand.nextInt(upperbound);
		}
		return int_random;
	}
	
	public void setName(String name, User user)
	{
		user.setKeyName(Name, name);
		Name = name;
	}
	
	public void addMember(User user, User requester)
	{
		if (requester.userEquals(Owner))
		{
			Members.put(user.Username, user);
			user.addBoard(this);
		}
		else
		{
			System.out.println("You cannot do this as you are not the owner.");
		}
	}
	
	public boolean verifyUser(User user)
	{
		boolean isIn;
		isIn = false;
		for (User i : Members.values()) 
		{
			if (user.userEquals(i))
			{
				isIn = true;
			}
		}
		return isIn;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		//System.out.println("Boards");

		Board otherBoard = (Board)obj;

		boolean isEqual;
		isEqual = true;
		
		if (this.getName().equals(otherBoard.getName()))
		{
			if (this.getOwner().userEquals(otherBoard.getOwner()))
			{
				if (this.getMembers().size()==otherBoard.getMembers().size())
				{
					for (String i : this.getMembers().keySet()) 
					{
						User mem1 = this.getMembers().get(i);
						User mem2 = otherBoard.getMembers().get(i);
						
						if (!mem1.userEquals(mem2))
						{
							isEqual = false;
						}
					}
				}
				else
				{
					isEqual = false;
				}
				if (this.getLists().size()==otherBoard.getLists().size())
				{
					for (int i = 0; i < this.getLists().size(); i++)
					{
					      List list1 = this.getLists().get(i);
					      List list2 = otherBoard.getLists().get(i);
					      
					      if(!list1.equals(list2))
					      {
					    	  isEqual = false;
					      }
				    }
				}
				else
				{
					isEqual = false;
				}
			}
			else
			{
				isEqual = false;
			}
		}
		else
		{
			isEqual = false;
		}
		return isEqual;
	}
	
	public void removeMember(User user, User requester)
	{
		if (requester.userEquals(Owner))
		{
			for (String i : Members.keySet()) 
			{
				  if (user.Username==i)
				  {
						Members.remove(user.Username);

				  }
			}
		}
		else
		{
			System.out.println("You cannot do this as you are not the owner.");
		}
	}
	
	/**
	 * 
	 */
	public Board()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the owner
	 */
	public User getOwner()
	{
		return Owner;
	}

	/**
	 * @param owner the owner to set
	 */
	public void setOwner(User owner)
	{
		Owner = owner;
	}

	/**
	 * @return the members
	 */
	public HashMap<String, User> getMembers()
	{
		return Members;
	}

	/**
	 * @param members the members to set
	 */
	public void setMembers(HashMap<String, User> members)
	{
		Members = members;
	}

	/**
	 * @return the lists
	 */
	public ArrayList<List> getLists()
	{
		return Lists;
	}

	/**
	 * @param lists the lists to set
	 */
	public void setLists(ArrayList<List> lists)
	{
		Lists = lists;
	}

	/**
	 * @return the name
	 */
	public String getName()
	{
		return Name;
	}

	public void addList(List list)
	{
			Lists.add(list);
	}
	
	public void removeList(List list)
	{
		for (int i=0; i<Lists.size(); i++)
		{
			if (list.equals(Lists.get(i)))
			{
				Lists.remove(i);
			}
		}
	}
	
	public void moveList(int old_idx, int new_idx)
	{
		List list = Lists.get(old_idx);
		List list2 = Lists.get(old_idx+new_idx);
		Lists.set(old_idx, list2);
		Lists.set(old_idx+new_idx, list);
//		for (int i=old_idx; i<new_idx; i++)
//		{
//			List list = Lists.get(i);
//			List temp = Lists.get(i+1);
//			Lists.set(i+1, list);
//			Lists.set(i, temp);
//		}
	}
	
}
