/**
 * 
 */
package Rello;

import java.io.*;
/**
 * @author guscrow
 *
 */
public interface Component extends Serializable
{

}