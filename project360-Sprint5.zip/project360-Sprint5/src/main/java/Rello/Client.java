package Rello;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;

public class Client
{
	public User me;
	public ServerInterface SS;
	public Registry registry;
	
	public Client(Registry registry, String bindName)
	{
		// TODO Auto-generated method stub
		try
		{
			this.registry = registry;
			SS = (ServerInterface) registry.lookup(bindName);
			
		} catch (RemoteException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Client(String ip)
	{
		try
		{
			SS = (ServerInterface) Naming.lookup(ip);
		} catch (MalformedURLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * @return the sS
	 */
	public ServerInterface getSS()
	{
		return SS;
	}

	/**
	 * @param sS the sS to set
	 */
	public void setSS(ServerInterface sS)
	{
		SS = sS;
	}

	/**
	 * @return the registry
	 */
	public Registry getRegistry()
	{
		return registry;
	}

	/**
	 * @param registry the registry to set
	 */
	public void setRegistry(Registry registry)
	{
		this.registry = registry;
	}

	public boolean loginUser(String username, String password)
	{
		//System.out.println("LoginUser");
		try
		{
			me = SS.Login(username, password);
			//System.out.println(me);
			if(me!=null)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (RemoteException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * @return the me
	 */
	public User getMe()
	{
		return me;
	}

	/**
	 * @param me the me to set
	 */
	public void setMe(User me)
	{
		this.me = me;
	}

	public void createBoard(String bname, User user)
	{
		try
		{
			me = SS.createBoard(bname, user);
		} catch (RemoteException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateBoard(User user, Board board)
	{
		try
		{
			me = SS.updateBoard(user, board);
		} catch (RemoteException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
