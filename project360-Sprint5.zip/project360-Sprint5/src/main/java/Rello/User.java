/**
 * 
 */
package Rello;

import java.util.HashMap; // import the HashMap class
import java.io.*;
/**
 * @author guscrow
 *
 */

public class User implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1684844327619673092L;
	public String Username;
	public String Password;
	public HashMap<String, Board> Boards = new HashMap<String, Board>();
	
	/**
	 * @param username
	 * @param password
	 */
	
	public User(String username, String password)
	{
		Username = username;
		Password = password;
	}
	
	/**
	 * @return the boards
	 */
	public HashMap<String, Board> getBoards()
	{
		return Boards;
	}

	/**
	 * @param boards the boards to set
	 */
	public void setBoards(HashMap<String, Board> boards)
	{
		Boards = boards;
	}

	/**
	 * 
	 */
	public User()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public boolean loginEquals(String username, String password)
	{
		if (this.Username.equals(username)&&this.getPassword().equals(password))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * @return the password
	 */
	public String getPassword()
	{
		return Password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password)
	{
		Password = password;
	}

	public Board createBoard(String name)
	{
		Board board = new Board(name, this);

		Boards.put(name, board);
		Server.Boards.put(Integer.toString(board.board_id), board);
		return board;
	}
	
	public void removeBoard(String name)
	{
		Boards.remove(name);
	}
	
	/**
	 * @return the username
	 */
	public String getUsername()
	{
		return Username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username)
	{
		Username = username;
	}


	public boolean userEquals(User user)
	{
		//System.out.println("inside userEquals");
		//System.out.println(this.getUsername()+user.getUsername());

		if (this.getUsername().equals(user.getUsername()))
		{
			//System.out.println("have same userName");

			return true;
		}
		else
		{
			//System.out.println("have different userName");

			return false;
		}
	}
	
	@Override
	public boolean equals(Object obj)
	{
		//System.out.println("User");

		User otherUser = (User)obj;
		
		boolean isEqual;
		isEqual = true;
		if (this.userEquals(otherUser))
		{
			//System.out.println("Users have same username");

			if (this.getBoards().size()==otherUser.getBoards().size())
			{
				for (String i : this.getBoards().keySet()) 
				{
					Board board1 = this.getBoard(i);
					
					Board board2 = otherUser.getBoard(i);
					
					if (!board1.equals(board2))
					{
						isEqual = false;
					}
				}
			}
			else
			{
				isEqual = false;
			}
		}
		else
		{
			isEqual = false;
		}
		return isEqual;
	}
	
	public void addBoard(Board board)
	{
		Boards.put(board.Name, board);
	}
	
	public Board getBoard(String name)
	{
		Board board = Boards.get(name);
		return board;
	}
	
	public User setBoard(String bname, Board board)
	{
		for (String i: this.getBoards().keySet())
		{
			String bname2 = this.getBoard(i).getName();
			if (bname2.equals(bname))
			{
				Boards.replace(bname, board);
			}
		}
		return this;
	}
	
	public void setKeyName(String old_name, String new_name)
	{
		Board board = this.getBoards().get(old_name);
		this.getBoards().put(new_name, board);
		this.getBoards().remove(old_name);
	}
}
