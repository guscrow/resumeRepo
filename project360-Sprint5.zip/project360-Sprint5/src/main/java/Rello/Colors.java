/**
 * 
 */
package Rello;

/**
 * @author guscrow
 *
 */
public enum Colors
{
	BLUE,
	GREEN,
	RED,
	YELLOW
}
