package Rello;

import java.util.ArrayList;

public class Iterator
{
	public Board board;

	public Iterator(Board board)
	{
		this.board = board;
	}
	
	public ArrayList<Card> getAllCards()
	{
		ArrayList<List> Lists = board.getLists();
		ArrayList<Card> allCards = new ArrayList<Card>();
		for (List list: Lists)
		{
			ArrayList<Card> Cards = list.getCards();
			for (Card card: Cards)
			{
				allCards.add(card);
			}
		}
		return allCards;
	}
	
}
