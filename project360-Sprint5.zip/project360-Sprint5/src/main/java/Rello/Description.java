/**
 * 
 */
package Rello;

/**
 * @author guscrow
 *
 */
public class Description implements Component
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7192796441881709248L;
	public String Description;
	
	public Description(String Description) 
	{
		this.Description = Description;
	}

	/**
	 * 
	 */
	public Description()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the description
	 */
	public String getDescription()
	{
		return Description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description)
	{
		Description = description;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		//System.out.println("Description");

		Description otherDescription = (Description)obj;
		
		boolean isEqual;
		isEqual = true;
		
		if(!this.getDescription().equals(otherDescription.getDescription()))
		{
			isEqual = false;
		}
		
		return isEqual;
	}
}
