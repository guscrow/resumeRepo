/**
 * 
 */
package Rello;

import java.util.ArrayList;

import java.util.EnumMap;
import java.io.*;
/**
 * @author guscrow
 *
 */
public class Card implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1541512189498760813L;
	public String Name;
	public ArrayList<User> Members = new ArrayList<User>();
	public EnumMap<Colors, Label> Labels = new EnumMap<Colors, Label>(Colors.class);
	public ArrayList<Component> Components = new ArrayList<Component>();
	public Board board;
	public Description description;
	public boolean Checked;
	
	/**
	 * @return the description
	 */
	public Description getDescription()
	{
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(Description description)
	{
		this.description = description;
	}

	/**
	 * @param name
	 * @param board
	 */
	public Card(String name, Board board)
	{
		Name = name;
		Checked = false;
		this.board = board;
	}
	
	/**
	 * @return the checked
	 */
	public boolean isChecked()
	{
		return Checked;
	}

	/**
	 * @param checked the checked to set
	 */
	public void setChecked(boolean checked)
	{
		Checked = checked;
	}

	public void addMember(User user)
	{
		boolean isMember = board.verifyUser(user);
		if (isMember==true)
		{
			Members.add(user);
		}
	}

	public void removeMember(int idx)
	{
		Members.remove(idx);
	}
		
	public void addComponent(Component component)
	{
		Components.add(component);
	}
	
	public void removeComponent(int idx)
	{
		Components.remove(idx);
	}
	
	public void addLabel(Colors color, Label label)
	{
		Labels.put(color, label);
	}
	
	/**
	 * 
	 */
	public Card()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the name
	 */
	public String getName()
	{
		return Name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		Name = name;
	}

	/**
	 * @return the members
	 */
	public ArrayList<User> getMembers()
	{
		return Members;
	}

	/**
	 * @param members the members to set
	 */
	public void setMembers(ArrayList<User> members)
	{
		Members = members;
	}

	/**
	 * @return the labels
	 */
	public EnumMap<Colors, Label> getLabels()
	{
		return Labels;
	}

	/**
	 * @param labels the labels to set
	 */
	public void setLabels(EnumMap<Colors, Label> labels)
	{
		Labels = labels;
	}

	/**
	 * @return the components
	 */
	public ArrayList<Component> getComponents()
	{
		return Components;
	}

	/**
	 * @param components the components to set
	 */
	public void setComponents(ArrayList<Component> components)
	{
		Components = components;
	}

	/**
	 * @return the board
	 */
	public Board getBoard()
	{
		return board;
	}

	/**
	 * @param board the board to set
	 */
	public void setBoard(Board board)
	{
		this.board = board;
	}

	public void removeLabel(Colors color)
	{
		Labels.remove(color);
	}
	
	@Override
	public boolean equals(Object obj)
	{
		//System.out.println("Card");

		Card otherCard = (Card)obj;
		
		boolean isEqual;
		isEqual = true;
		
		if (this.getName().equals(otherCard.getName()))
		{
			if (this.getBoard().getName().equals(otherCard.getBoard().getName()))
			{
				if (this.getComponents().size()==otherCard.getComponents().size())
				{
					for (int i = 0; i < this.getComponents().size(); i++)
					{
					      Component component1 = this.getComponents().get(i);
					      Component component2 = otherCard.getComponents().get(i);
					      if (component1.getClass()==component2.getClass())
					      {
						      if(!component1.equals(component2))
						      {
						    	  isEqual = false;
						      }
					      }
					      else
					      {
					    	  isEqual = false;
					      }
				    }
				}
				else
				{
					isEqual = false;
				}
				if (this.getMembers().size()==otherCard.getMembers().size())
				{
					for (int i = 0; i < this.getComponents().size(); i++) 
					{
						User mem1 = this.getMembers().get(i);
						User mem2 = otherCard.getMembers().get(i);
						
						if (!mem1.userEquals(mem2))
						{
							isEqual = false;
						}
					}
				}
				else
				{
					isEqual = false;
				}
				if (this.getLabels().size()==otherCard.getLabels().size())
				{
					for (Colors color: this.getLabels().keySet())
					{
						if(!this.Labels.get(color).equals(otherCard.Labels.get(color)))
						{
							isEqual = false;
						}
					}
				}
				else
				{
					isEqual = false;
				}
			}
			else
			{
				isEqual = false;
			}
		}
		else
		{
			isEqual = false;
		}
		
		
		return isEqual;
	}
}
