package Rello;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList; // import the ArrayList class
import java.util.HashMap; // import the HashMap class


import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


public class Server extends UnicastRemoteObject implements ServerInterface
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1885367873974928530L;
	public static ArrayList<User> userList = new ArrayList<User>();
	public static HashMap<String, Board> Boards = new HashMap<String, Board>();

	
	public static void main(String[] args)
	{
		
	}
	
	public void closeServer(Registry registry) throws RemoteException
	{
		try
		{
			registry.unbind("RELLO");
			storeToDisk();
		} catch (RemoteException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Registry bootServer(String bindName) throws RemoteException
	{

		Registry registry = LocateRegistry.createRegistry(2099);
		registry.rebind(bindName,this);
		
		Server.setUserList(Server.loadFromDisk());
		for(int i = 0; i<userList.size(); i++)
		{
			loadBoards(userList.get(i));
		}
		return registry;
	}
	
	public void loadBoards(User user)
	{
		for(Board board:user.getBoards().values())
		{
			if(!Boards.containsKey(Integer.toString(board.getBoard_id())))
			{
				Boards.put(Integer.toString(board.getBoard_id()), board);
			}
		}
	}
	/**
	 * @return the userList
	 */
	public static ArrayList<User> getUserList()
	{
		return userList;
	}

	/**
	 * @param userList the userList to set
	 */
	public static void setUserList(ArrayList<User> userList)
	{
		Server.userList = userList;
	}

	/**
	 * @return the boards
	 */
	public static HashMap<String, Board> getBoards()
	{
		return Boards;
	}

	/**
	 * @param boards the boards to set
	 */
	public void setBoards(HashMap<String, Board> boards)
	{
		Boards = boards;
	}

	/**
	 * 
	 */
	
	public Server() throws RemoteException
	{
		
	}
	
	public void addUser(User user)
	{
		userList.add(user);
	}
	
	public void storeToDisk()
	{
		XMLEncoder encoder=null;
		try{
		encoder=new XMLEncoder(new BufferedOutputStream(new FileOutputStream("data.xml")));
		}catch(FileNotFoundException fileNotFound){
			System.out.println("ERROR: While Creating or Opening the File data.xml");
		}
		encoder.writeObject(userList);
		encoder.close();
	}

	public static ArrayList<User> loadFromDisk()
	{
		XMLDecoder decoder=null;
		try {
			decoder=new XMLDecoder(new BufferedInputStream(new FileInputStream("data.xml")));
		} catch (FileNotFoundException e) {
			System.out.println("ERROR: File data.xml not found");
		}
		@SuppressWarnings("unchecked")
		ArrayList<User> export=(ArrayList<User>)decoder.readObject();
		return export;
	}
	
	public static ArrayList<User> loadFromDisk(String filename)
	{
		XMLDecoder decoder=null;
		try {
			decoder=new XMLDecoder(new BufferedInputStream(new FileInputStream(filename)));
		} catch (FileNotFoundException e) {
			System.out.println("ERROR: File data.xml not found");
		}
		@SuppressWarnings("unchecked")
		ArrayList<User> export=(ArrayList<User>)decoder.readObject();
		return export;
	}
	/**
	 * @return the users
	 */
	public ArrayList<User> getUsers()
	{
		return userList;
	}

	/**
	 * @param users the users to set
	 */
	public void setUsers(ArrayList<User> users)
	{
		userList = users;
	}

	@Override 
	public boolean equals(Object obj) 
	{
		boolean isEqual;
		isEqual = true;
		if (Server.userList.size()==Server.userList.size())
		{
			for (int i = 0; i < Server.userList.size(); i++)
			{
			      User user1 = Server.userList.get(i);
			      User user2 = Server.userList.get(i);
			      
			      if(user1.equals(user2)==false)
			      {
			    	  isEqual = false;
			      }
		    }
		}
		else
		{
			isEqual = false;
		}
		
		return isEqual;
	}

	@Override
	public User createBoard(String bname, User user) throws RemoteException
	{
		user.createBoard(bname);
		return user;
	}

	@Override
	public User Login(String username, String password) throws RemoteException
	{
		//System.out.println("Login"+userList);
		for(int i = 0; i < userList.size(); i++)
		{
			//System.out.println(userList.get(i).getUsername()+userList.get(i).getPassword() +username+password);
			if(userList.get(i).loginEquals(username,password))
			{
				//System.out.println(userList.get(i).getUsername());
				return userList.get(i);
			}
		}
		return null;
	}

	@Override
	public User updateBoard(User user, Board board) throws RemoteException
	{
		int i;
		int pos = 0;
		for (i = 0; i<userList.size(); i++)
		{
			if(user.userEquals(userList.get(i)))
			{
				pos = i;
			}
		}
		User new_user = user.setBoard(board.getName(), board);
		userList.set(pos, new_user);
		return new_user;
	}

	
}
