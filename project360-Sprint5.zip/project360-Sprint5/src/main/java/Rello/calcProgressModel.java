package Rello;

import java.util.ArrayList;

public class calcProgressModel
{

	public Iterator iterator;

	public calcProgressModel(Iterator iterator)
	{
		this.iterator = iterator;
	}
	
	public double calculateProgressOfBoard()
	{
		ArrayList<Card> allCards = iterator.getAllCards();
		int totalNumOfCards = allCards.size();
		int numOfCardsCompleted = 0;
		for(Card card: allCards)
		{
			if(card.isChecked())
			{
				numOfCardsCompleted = numOfCardsCompleted +1;
			}
		}
		
		double percentComplete = 0;
		//System.out.println(numOfCardsCompleted);
		//System.out.println(totalNumOfCards);
		percentComplete = (double)numOfCardsCompleted/(double)totalNumOfCards;
		//System.out.println(percentComplete);
		return percentComplete;
	}
}
