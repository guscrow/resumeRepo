/**
 * 
 */
package Rello;

import java.util.ArrayList; // import the ArrayList class
import java.io.*;
/**
 * @author guscrow
 *
 */
public class List implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5381316635819343131L;
	String Name;
	ArrayList<Card> Cards = new ArrayList<Card>();
	Board board;
	
	/**
	 * @param name
	 * @param board
	 */
	public List(String name, Board board)
	{
		Name = name;
		this.board = board;
	}

	public void setName(String name)
	{
		Name = name;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		//System.out.println("List");

		List otherList = (List)obj;
		
		boolean isEqual;
		isEqual = true;
		
		if (this.getName().equals(otherList.getName()))
		{
			if (this.getBoard().getName().equals(otherList.getBoard().getName()))
			{
				if (this.getCards().size()==otherList.getCards().size())
				{
					for (int i = 0; i < this.getCards().size(); i++)
					{
					      Card card1 = this.getCards().get(i);
					      Card card2 = otherList.getCards().get(i);
					      
					      if(!card1.equals(card2))
					      {
					    	  isEqual = false;
					      }
				    }
				}
				else
				{
					isEqual = false;
				}
			}
			else
			{
				isEqual = false;
			}
		}
		else 
		{
			isEqual = false;
		}
		
		return isEqual;
	}
	
	public void addCard(Card card)
	{
		Cards.add(card);
	}
	
	public void removeCard(int idx)
	{
		Cards.remove(idx);
	}
	
	/**
	 * 
	 */
	public List()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the cards
	 */
	public ArrayList<Card> getCards()
	{
		return Cards;
	}

	/**
	 * @param cards the cards to set
	 */
	public void setCards(ArrayList<Card> cards)
	{
		Cards = cards;
	}

	/**
	 * @return the board
	 */
	public Board getBoard()
	{
		return board;
	}

	/**
	 * @param board the board to set
	 */
	public void setBoard(Board board)
	{
		this.board = board;
	}

	/**
	 * @return the name
	 */
	public String getName()
	{
		return Name;
	}

	public void addMemberToAllCards(User user)
	{
		for (int i = 0; i < Cards.size(); i++)
		{
		      Card card = Cards.get(i);
		      card.addMember(user);
	    }
	}
	
	public void moveCardInList(int old_idx, int new_idx)
	{
		Card card = Cards.get(old_idx);
		Card card2 = Cards.get(old_idx+new_idx);
		Cards.set(old_idx, card2);
		Cards.set(old_idx+new_idx, card);
//		for (int i=old_idx; i<new_idx; i++)
//		{
//			Card card = Cards.get(i);
//			Card temp = Cards.get(i+1);
//			Cards.set(i+1, card);
//			Cards.set(i, temp);
//		}
	}
	
	public void moveCardToList(int idx, List list)
	{
		Card card = this.getCards().get(idx);
		this.removeCard(idx);
		list.addCard(card);
	}
}
