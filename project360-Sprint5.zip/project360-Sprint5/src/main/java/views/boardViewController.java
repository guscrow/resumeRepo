package views;

import java.io.IOException;
import java.util.ArrayList;


import Rello.Board;
import Rello.Client;
import Rello.Iterator;
import Rello.List;
import Rello.User;
import Rello.calcProgressModel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class boardViewController
{
		@FXML
	    private HBox boardStorageBox;

	    @FXML
	    private Button addNewListButton;

	    @FXML
	    private Button exitApplicationButton;

	    @FXML
	    private Button backButton;

	    @FXML
	    private TextField boardNameTB;

	    @FXML
	    private Button addMemberButton;
	    
	    @FXML
	    private Button viewProgressButton;

		private Client client;

		private Stage primaryStage;

		private Board board;
		
		public void setBoard(Board board)
		{
			this.board = board;
			boardNameTB.setText(board.getName());
			ArrayList<List> Lists = board.getLists();
			for(List list: Lists)
			{
				FXMLLoader loader = new FXMLLoader();
	    		loader.setLocation(User.class.getResource("../views/listView.fxml"));
	    		BorderPane view;
	    		try
				{
					view = loader.load();
					view.setId(list.getName());
					listViewController cont = loader.getController();
					cont.setClient(client);
		    		cont.setModel(list);
		    		cont.setStage(primaryStage);
					boardStorageBox.getChildren().add(view);
				} catch (IOException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    		
			}
		}

	    public void setModel(Client client)
	    {
			System.out.println("BoardView"+client);
	    	this.client = client;
	    }
	    
	    public void setStage(Stage stage)
	    {
	    	this.primaryStage = stage;
	    }
	    
	    @FXML
	    void onClickAddMem(ActionEvent event) 
	    {

	    }

	    @FXML
	    void onClickBackButton(ActionEvent event) 
	    {
	    	board.setName(boardNameTB.getText(), client.getMe());
	    	ArrayList<List> Lists = board.getLists();
//			for (List list: Lists)
//			{
//				String listName = list.getName();
//				String selector = "#"+listName;
//				BorderPane listview = (BorderPane) boardStorageBox.lookup(selector);
//				TextField listNameTB = (TextField) listview.lookup("#listNameTB");
//				list.setName(listNameTB.getText());
//			}
//	    	System.out.println(board);
//	    	System.out.println(client.getMe().getBoards());
	    	client.getMe().addBoard(board);
			client.updateBoard(client.getMe(), board);
	    	FXMLLoader loader = new FXMLLoader();
    		loader.setLocation(User.class.getResource("../views/boardListingView.fxml"));
    		BorderPane view;
			try
			{
				view = loader.load();
				boardListingViewController cont = loader.getController();
	    		cont.setStage(primaryStage);
	    		User user = client.getMe();
	    		cont.setModel(user);
	    		cont.setClient(client);
	    		Scene s = new Scene(view);
	    		primaryStage.setScene(s);
	    		primaryStage.show();
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    @FXML
	    void onClickExit(ActionEvent event) 
	    {
	    	primaryStage.close();
	    }

	    @FXML
	    void onNewListClick(ActionEvent event) 
	    {
	    	FXMLLoader loader = new FXMLLoader();
    		loader.setLocation(User.class.getResource("../views/listCreateView.fxml"));
    		BorderPane view;
    		System.out.println("BoardVIewcontroller"+client);
			try
			{
				view = loader.load();
				listCreateViewController cont = loader.getController();
	    		cont.setStage(primaryStage);
	    		cont.setModel(board);
	    		cont.setClient(client);
	    		Scene s = new Scene(view);
	    		primaryStage.setScene(s);
	    		primaryStage.show();
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void onChangedName(InputMethodEvent event) 
	    {
	    	System.out.println("Changed Name");
	    	board.setName(boardNameTB.getText(), client.getMe());
	    	System.out.println(board.getName());
	    }
	    
	    @FXML
	    void onClickViewProgressButton(ActionEvent event) 
	    {
	    	FXMLLoader loader = new FXMLLoader();
    		loader.setLocation(User.class.getResource("../views/progressView.fxml"));
    		BorderPane view;
    		
			try
			{
				view = loader.load();
				progressViewController cont = loader.getController();
	    		cont.setStage(primaryStage);
	    		Iterator iterator = new Iterator(board);
	    		calcProgressModel nextModel = new calcProgressModel(iterator);
	    		cont.setModel(nextModel);
	    		cont.setClient(client);
	    		Scene s = new Scene(view);
	    		primaryStage.setScene(s);
	    		primaryStage.show();
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
}
