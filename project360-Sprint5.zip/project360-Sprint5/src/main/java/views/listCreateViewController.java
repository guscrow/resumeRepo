package views;

import java.io.IOException;

import Rello.Board;
import Rello.Client;
import Rello.List;
import Rello.User;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

public class listCreateViewController
{
	
	private Board board;
	private Stage primaryStage;
	private Client client;

	public void setModel(Board board)
    {
    	this.board = board;
    }
    
    public void setStage(Stage stage)
    {
    	this.primaryStage = stage;
    }

	public void setClient(Client client)
	{
		this.client = client;
	}
	
	@FXML
    private TextField listNameTB;

    @FXML
    private Button cancelButton;

    @FXML
    private Button createButton;

    @FXML
    void onClickCancelButton(ActionEvent event) 
    {
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(client);
    		cont.setBoard(board);
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void onClickCreateButton(ActionEvent event) 
    {
//    	System.out.println(client);
//		System.out.println(board);
//		System.out.println(primaryStage);
    	List list = new List(listNameTB.getText(),board);
    	board.addList(list);
    	client.updateBoard(client.getMe(), board);
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();

    		cont.setStage(primaryStage);
    		cont.setModel(client);
    		cont.setBoard(board);
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
}
