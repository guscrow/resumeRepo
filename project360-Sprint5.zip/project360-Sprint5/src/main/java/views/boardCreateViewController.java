package views;

import java.io.IOException;
import java.util.HashMap;

import Rello.Board;
import Rello.Client;
import Rello.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class boardCreateViewController
{
	@FXML
    private TextField boardNameTB;

    @FXML
    private Button cancelButton;

    @FXML
    private Button createButton;

	private Client model;

	private Stage primaryStage;

    public void setModel(Client model)
	{
		this.model = model;
	}
    
    public void setStage(Stage stage)
    {
    	this.primaryStage = stage;
    }
    
    @FXML
    void onClickCancelButton(ActionEvent event) 
    {
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardListingView.fxml"));
		BorderPane view;
		
		try
		{
			view = loader.load();
			boardListingViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setClient(model);
    		cont.setModel(model.getMe());
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void onClickCreateButton(ActionEvent event) 
    {
    	model.createBoard(boardNameTB.getText(), model.getMe());
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardListingView.fxml"));
		BorderPane view;
		
		try
		{
			view = loader.load();
			boardListingViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setClient(model);
    		cont.setModel(model.getMe());
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
