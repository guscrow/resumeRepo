package views;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.HashMap;

import Rello.Board;
import Rello.Client;
import Rello.User;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class boardListingViewController
{
	 	@FXML
	    private FlowPane boardsFlowPane;

	    @FXML
	    private Button addBoardButton;

	    @FXML
	    private Button logoutButton;

		public User model;
		
		public Client client;
		
		public Stage primaryStage;
	    
	    public void setModel(User model)
		{
			this.model = model;
			HashMap<String, Board> Boards;
			Boards = model.getBoards();
			for (Board i : Boards.values()) 
			{
				Button button = new Button(i.getName());
				button.setPrefHeight(80);
				button.setPrefWidth(80);
				//System.out.println(i.getName());
				button.setId(i.getName());
				button.setOnAction((ActionEvent event) -> {
					FXMLLoader loader = new FXMLLoader();
		    		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		    		BorderPane view;
					try
					{
						view = loader.load();
						boardViewController cont = loader.getController();
			    		cont.setStage(primaryStage);
			    		cont.setModel(client);
			    		cont.setBoard(i);
			    		Scene s = new Scene(view);
			    		primaryStage.setScene(s);
			    		primaryStage.show();
					} catch (IOException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				});
				boardsFlowPane.getChildren().add(button);
			}
		}
	    
	    public void setClient(Client client)
	    {
	    	this.client = client;
	    }
	    
	    public void setStage(Stage stage)
	    {
	    	this.primaryStage = stage;
	    }
	    
	    @FXML
	    void onClickAddBoard(ActionEvent event) 
	    {
	    	FXMLLoader loader = new FXMLLoader();
    		loader.setLocation(User.class.getResource("../views/boardCreateView.fxml"));
    		BorderPane view;
    		
			try
			{
				view = loader.load();
				boardCreateViewController cont = loader.getController();
	    		cont.setStage(primaryStage);
	    		cont.setModel(client);
	    		Scene s = new Scene(view);
	    		primaryStage.setScene(s);
	    		primaryStage.show();
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    @FXML
	    void onClickLogoutButton(ActionEvent event) 
	    {
	    	primaryStage.close();
	    }
}
