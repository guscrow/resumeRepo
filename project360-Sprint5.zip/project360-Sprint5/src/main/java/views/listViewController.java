package views;

import java.io.IOException;
import java.util.ArrayList;

import Rello.Board;
import Rello.Card;
import Rello.Client;
import Rello.List;
import Rello.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class listViewController
{
	
	@FXML
    private TextField listNameTB;

	@FXML
    private Button saveButton;
	
    @FXML
    private Button editButton;

    @FXML
    private Button addNewCardButton;

    @FXML
    private VBox cardStorageBox;
    
    @FXML
    private Button moveLeftButton;
    
    @FXML
    private Button moveRightButton;
    
	List list;

	Stage primaryStage;

	Client client;

    public void setModel(List list)
    {
    	this.list = list;
    	listNameTB.setText(list.getName());
    	ArrayList<Card> Cards = list.getCards();
    	for (Card card: Cards)
    	{
    		Button button = new Button(card.getName());
    		CheckBox checkbox = new CheckBox();
    		//checkbox.setId(card.getName()+"cb");
    		//button.setGraphic(checkbox);
			button.setPrefHeight(50);
			button.setPrefWidth(350);
			button.setId(card.getName());
			button.setOnAction((ActionEvent event) -> {
				FXMLLoader loader = new FXMLLoader();
	    		loader.setLocation(User.class.getResource("../views/cardEditView.fxml"));
	    		BorderPane view;
				try
				{
					view = loader.load();
					cardEditViewController cont = loader.getController();
		    		cont.setStage(primaryStage);
		    		cont.setModel(card);
		    		cont.setList(list);
		    		cont.setClient(client);
		    		Scene s = new Scene(view);
		    		primaryStage.setScene(s);
		    		primaryStage.show();
				} catch (IOException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			cardStorageBox.getChildren().add(button);
    	}
    	
    }
    
    public void setStage(Stage stage)
    {
    	this.primaryStage = stage;
    }

	public void setClient(Client client)
	{
		this.client = client;
	}
    
    @FXML
    void onClickAddNewCard(ActionEvent event) 
    {
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/cardCreateView.fxml"));
		BorderPane view;
		
		try
		{
			view = loader.load();
			cardCreateViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(list);
    		cont.setClient(client);
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void onClickEditButton(ActionEvent event) 
    {
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/listActionsView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			listActionsViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(list);
    		cont.setClient(client);
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @FXML
    void onClickMoveLeft(ActionEvent event) 
    {
    	int pos = 0;
    	Board board = list.getBoard();
    	ArrayList<List> Lists = list.getBoard().getLists();
    	pos = Lists.indexOf(list);
    	//System.out.println(Lists);
    	if(pos>0)
    	{
    		board.moveList(pos, -1);
    	}
    	//System.out.println(Lists);
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(client);
    		cont.setBoard(board);
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void onClickMoveRight(ActionEvent event) 
    {
    	int pos = 0;
    	Board board = list.getBoard();
    	ArrayList<List> Lists = list.getBoard().getLists();
    	pos = Lists.indexOf(list);
    	if(pos<Lists.size())
    	{
    		board.moveList(pos, 1);
    	}
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(client);
    		cont.setBoard(board);
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @FXML
    void onClickSaveButton(ActionEvent event) 
    {
    	list.setName(listNameTB.getText());
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		//System.out.println(client.getMe().getBoards()+"insidesave");
    		cont.setModel(client);
    		cont.setBoard(list.getBoard());
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
