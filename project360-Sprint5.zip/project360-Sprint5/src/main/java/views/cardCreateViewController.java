package views;

import java.io.IOException;

import Rello.Card;
import Rello.Client;
import Rello.List;
import Rello.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class cardCreateViewController
{
	 	@FXML
	    private TextField cardNameTB;

	    @FXML
	    private Button cancelButton;

	    @FXML
	    private Button createButton;

	    List list;

		Stage primaryStage;

		Client client;

	    public void setModel(List list)
	    {
	    	this.list = list;
	    }
	    
	    public void setStage(Stage stage)
	    {
	    	this.primaryStage = stage;
	    }

		public void setClient(Client client)
		{
			System.out.println("CardCreateView"+client);

			this.client = client;
		}
	    
	    @FXML
	    void onClickCancelButton(ActionEvent event) 
	    {
	    	FXMLLoader loader = new FXMLLoader();
			loader.setLocation(User.class.getResource("../views/boardView.fxml"));
			BorderPane view;
			try
			{
				view = loader.load();
				boardViewController cont = loader.getController();
	    		cont.setStage(primaryStage);
	    		cont.setModel(client);
	    		cont.setBoard(list.getBoard());
	    		Scene s = new Scene(view);
	    		primaryStage.setScene(s);
	    		primaryStage.show();
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    @FXML
	    void onClickCreateButton(ActionEvent event) 
	    {
	    	Card card = new Card(cardNameTB.getText(),list.getBoard());
	    	list.addCard(card);
	    	//client.updateBoard(client.getMe(), list.getBoard());
	    	FXMLLoader loader = new FXMLLoader();
			loader.setLocation(User.class.getResource("../views/boardView.fxml"));
			BorderPane view;
			try
			{
				view = loader.load();
				boardViewController cont = loader.getController();
	    		cont.setStage(primaryStage);
	    		cont.setModel(client);
	    		cont.setBoard(list.getBoard());
	    		Scene s = new Scene(view);
	    		primaryStage.setScene(s);
	    		primaryStage.show();
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
}
