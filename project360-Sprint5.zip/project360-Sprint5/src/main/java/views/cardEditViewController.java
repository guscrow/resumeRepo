package views;

import java.io.IOException;
import java.util.ArrayList;

import Rello.Board;
import Rello.Card;
import Rello.Client;
import Rello.Description;
import Rello.List;
import Rello.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class cardEditViewController
{
	@FXML
    private TextField cardNameTB;

    @FXML
    private Button saveButton;

    @FXML
    private Button addLabelButton;
    
    @FXML
    private TextArea descBox;
    
    @FXML
    private CheckBox compCheckBox;
    
    @FXML
    private Button removeButton;
    
    @FXML
    private Button moveUpButton;

    @FXML
    private Button moveDownButton;

	private Stage primaryStage;

	private Client client;

	private Card card;

	private List list;
	
	public void setList(List list)
	{
		this.list = list;
	}
	
	public void setModel(Card card)
	{
		this.card = card;
		cardNameTB.setText(card.getName());
		compCheckBox.setSelected(card.isChecked());
		if(card.getDescription()!=null)
		{
			descBox.setText(card.getDescription().getDescription());
		}
	}

    public void setStage(Stage stage)
    {
    	this.primaryStage = stage;
    }

	public void setClient(Client client)
	{
		System.out.println("cardEditView"+client);
		this.client = client;
	}
    
    @FXML
    void onClickAddLabel(ActionEvent event) 
    {

    }

    @FXML
    void onClickSaveButton(ActionEvent event) 
    {
    	Description description = new Description(descBox.getText());
    	card.setDescription(description);
    	card.setName(cardNameTB.getText());
    	card.setChecked(compCheckBox.isSelected());
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(client);
    		cont.setBoard(card.getBoard());
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
    	
    }
    
    @FXML
    void onNameChanged(InputMethodEvent event) 
    {
    	card.setName(cardNameTB.getText());
    }
    
    @FXML
    void onRemoveButton(ActionEvent event) 
    {
    	ArrayList<Card> Cards = list.getCards();
    	for(int i = 0; i<list.getCards().size(); i++)
    	{
    		if (card.equals(Cards.get(i)))
    		{
    			list.removeCard(i);
    		}
    	}
    	//client.updateBoard(client.getMe(), card.board);
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(client);
    		cont.setBoard(card.getBoard());
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
    }
    
    @FXML
    void onClickMoveDownButton(ActionEvent event) 
    {
    	int pos = 0;
    	Board board = list.getBoard();
    	ArrayList<Card> Cards = list.getCards();
    	pos = Cards.indexOf(card);
    	//System.out.println(Lists);
    	if(pos<Cards.size())
    	{
    		list.moveCardInList(pos, 1);
    	}
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(client);
    		cont.setBoard(card.getBoard());
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
    }

    @FXML
    void onClickMoveUpButton(ActionEvent event) 
    {
    	int pos = 0;
    	Board board = list.getBoard();
    	ArrayList<Card> Cards = list.getCards();
    	pos = Cards.indexOf(card);
    	//System.out.println(Lists);
    	if(pos>0)
    	{
    		list.moveCardInList(pos, -1);
    	}
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(client);
    		cont.setBoard(card.getBoard());
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
    }
}
