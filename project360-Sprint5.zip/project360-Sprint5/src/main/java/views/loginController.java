package views;

import java.io.IOException;

import Rello.Client;
import Rello.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class loginController
{
	
		Client model;
	
		@FXML
	    private Label incNamePassLabel;
		
		@FXML
	    private TextField userNameTB;

	    @FXML
	    private PasswordField passwordTB;

	    @FXML
	    private Button signInButton;

		public Stage primaryStage;

	    public void setModel(Client model)
		{
			this.model = model;
		}
	    
	    public void setStage(Stage stage)
	    {
	    	this.primaryStage = stage;
	    }
	    
	    @FXML
	    void onSignInClick(ActionEvent event) 
	    {
	    	boolean signIn = model.loginUser(userNameTB.getText(), passwordTB.getText());
	    	userNameTB.clear();
	    	passwordTB.clear();
	    	if (signIn==false)
	    	{
	    		incNamePassLabel.setVisible(true);
	    	}
	    	else
	    	{
	    		incNamePassLabel.setVisible(false);
	    		//System.out.println("login successful");
	    		FXMLLoader loader = new FXMLLoader();
	    		loader.setLocation(User.class.getResource("../views/boardListingView.fxml"));
	    		BorderPane view;
	    		
				try
				{
					view = loader.load();
					boardListingViewController cont = loader.getController();
		    		cont.setStage(primaryStage);
		    		User user = model.getMe();
		    		cont.setModel(user);
		    		cont.setClient(model);
		    		Scene s = new Scene(view);
		    		primaryStage.setScene(s);
		    		primaryStage.show();
				} catch (IOException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    		
	    	}
	    }
}
