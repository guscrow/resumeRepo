package views;

import java.io.IOException;

import Rello.Client;
import Rello.List;
import Rello.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class listActionsViewController
{
	  	@FXML
	    private Button removeButton;

	    @FXML
	    private Button moveListButton;

		private Stage primaryStage;

		private Client client;

		private List list;

	    public void setStage(Stage stage)
	    {
	    	this.primaryStage = stage;
	    }

		public void setClient(Client client)
		{
			this.client = client;
		}
		
		public void setModel(List list)
		{
			this.list = list;
		}
	    
	    
	    @FXML
	    void onClickMoveList(ActionEvent event) 
	    {

	    }

	    @FXML
	    void onClickRemove(ActionEvent event) 
	    {
	    	list.getBoard().removeList(list);
	    	//client.updateBoard(client.getMe(), list.getBoard());
	    	FXMLLoader loader = new FXMLLoader();
			loader.setLocation(User.class.getResource("../views/boardView.fxml"));
			BorderPane view;
			try
			{
				view = loader.load();
				boardViewController cont = loader.getController();
	    		cont.setStage(primaryStage);
	    		cont.setModel(client);
	    		cont.setBoard(list.getBoard());
	    		Scene s = new Scene(view);
	    		primaryStage.setScene(s);
	    		primaryStage.show();
			} catch (IOException e)
			{
				e.printStackTrace();
			}
	    }
}
