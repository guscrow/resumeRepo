package views;

import java.io.IOException;

import Rello.Board;
import Rello.Client;
import Rello.User;
import Rello.calcProgressModel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class progressViewController
{
    @FXML
    private ProgressBar progressBar;

    @FXML
    private ProgressIndicator progressIndicator;

    @FXML
    private Button backButton;

	private Stage primaryStage;

	private calcProgressModel model;

	private Client client;

    @FXML
    void onClickBackButton(ActionEvent event) 
    {
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(User.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			boardViewController cont = loader.getController();
    		cont.setStage(primaryStage);
    		cont.setModel(client);
    		cont.setBoard(model.iterator.board);
    		Scene s = new Scene(view);
    		primaryStage.setScene(s);
    		primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	public void setStage(Stage primaryStage)
	{
		this.primaryStage = primaryStage;
	}

	public void setModel(calcProgressModel model)
	{
		this.model = model;	
		progressBar.setProgress(model.calculateProgressOfBoard());
		progressIndicator.setProgress(model.calculateProgressOfBoard());
	}
	
	public void setClient(Client client)
    {
		System.out.println("progressView"+client);
    	this.client = client;
    }
	
}
