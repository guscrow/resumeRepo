package views;

import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;

import Rello.Board;
import Rello.Client;
import Rello.Server;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ServerViewController
{
	
	public static Client client;
	Stage primaryStage;
	
	@FXML
    private Button defaultButton;

    @FXML
    private TextField IPTextBox;

    @FXML
    private Button EnterIPButon;

    public void setStage(Stage stage)
    {
    	this.primaryStage = stage;
    }
    
    @FXML
    void onDefaultClick(ActionEvent event) throws RemoteException 
    {
    	client = new Client("rmi://localhost/RELLO");
		
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Board.class.getResource("../views/loginView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			loginController cont = loader.getController();
			cont.setModel(client);
			cont.setStage(primaryStage);
			
			Scene s = new Scene(view);
			primaryStage.setScene(s);
			primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }

    @FXML
    void onEnterIPClick(ActionEvent event) 
    {
    	client = new Client(IPTextBox.getText());
		
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Board.class.getResource("../views/loginView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			loginController cont = loader.getController();
			cont.setModel(client);
			cont.setStage(primaryStage);
			
			Scene s = new Scene(view);
			primaryStage.setScene(s);
			primaryStage.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
