import java.rmi.RemoteException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import views.ServerViewController;

public class Main extends Application
{
	ServerViewController cont; 
	public static void main(String[] args)
	{
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception
	{
		
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("views/ServerView.fxml"));
		BorderPane view = loader.load();
		cont = loader.getController();
		cont.setStage(primaryStage);
		Scene s = new Scene(view);
		primaryStage.setScene(s);
		primaryStage.show();

	}
	
	@Override
	public void stop()
	{
//		try
//		{
//			cont.sv.closeServer(cont.client.registry);
//		} catch (RemoteException e)
//		{
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		// Save file
	}
}
