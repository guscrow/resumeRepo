package Rello;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ListTest
{
	User gus;
	User josh;
	User testUser;
	Board board;
	List list;
	
	@BeforeEach
	void setUp() throws Exception
	{
		gus = new User("gus","crow");
		josh = new User("josh","west");
		testUser = new User("test","user");
		board = new Board("board1",gus);
		board.addMember(josh, gus);
		list = new List("list1",board);
	}

	@Test
	void testEqualsList()
	{
		List list2 = new List("list2", board);
		assert list.equals(list2)==false;
		assert list.equals(list);
	}

	@Test
	void testAddCard()
	{
		Card card = new Card("card1",board);
		assert list.Cards.size()==0;
		list.addCard(card);
		assert list.Cards.size()==1;
	}

	@Test
	void testRemovecard()
	{
		Card card = new Card("card1",board);
		assert list.Cards.size()==0;
		list.addCard(card);
		assert list.Cards.size()==1;
		list.removeCard(0);
		assert list.Cards.size()==0;
	}

	@Test
	void testAddMemberToAllCards()
	{
		Card card = new Card("card1", board);
		Card card2 = new Card("card2", board);
		Card card3 = new Card("card3", board);
		
		list.addCard(card);
		list.addCard(card2);
		list.addCard(card3);

		list.addMemberToAllCards(josh);
		assert card.Members.size()==1;
		assert card.Members.get(0).userEquals(josh);
		assert card2.Members.get(0).userEquals(josh);
		assert card3.Members.get(0).userEquals(josh);
		list.addMemberToAllCards(testUser);
		assert card.Members.size()==1;

	}

	@Test
	void testMoveCardInList()
	{
		Card card = new Card("card1", board);
		Card card2 = new Card("card2", board);
		Card card3 = new Card("card3", board);
		
		list.addCard(card);
		list.addCard(card2);
		list.addCard(card3);
		
		list.moveCardInList(0, 2);
		assert list.Cards.get(0).equals(card2);
		assert list.Cards.get(1).equals(card3);
		assert list.Cards.get(2).equals(card);
	}
	
	@Test
	void testMoveCardToList()
	{
		Card card = new Card("card1", board);
		Card card2 = new Card("card2", board);
		Card card3 = new Card("card3", board);
		
		Board board2 = new Board("board2",gus);
		List list2 = new List("list2",board2);
		
		
		list.addCard(card);
		list2.addCard(card2);
		list.addCard(card3);
		
		assert list.getCards().size()==2;
		assert list2.getCards().size()==1;
		list.moveCardToList(0, list2);

		assert list.getCards().get(0).equals(card3);
		assert list.getCards().size()==1;
		assert list2.getCards().size()==2;
		assert list2.getCards().get(1).equals(card);

	}

}
