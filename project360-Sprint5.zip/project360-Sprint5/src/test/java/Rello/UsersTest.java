package Rello;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UsersTest
{
	Server u;
	User gus;
	User josh;
	User testUser;
	Board board;
	List list;
	Card card;
	
	@BeforeEach
	void setUp() throws Exception
	{
		u = new Server();
		gus = new User("gus","crow");
		josh = new User("josh","west");
		//testUser = new User("test","user");
		board = gus.createBoard("gusBoard");
		board.addMember(josh, gus);
		list = new List("list1",board);
		board.addList(list);
		card = new Card("card1",board);
		list.addCard(card);	
		u.addUser(gus);
		u.addUser(josh);
		//u.addUser(testUser);
	}

	@Test
	void test()
	{
		u.storeToDisk();
		ArrayList<User> serverUsers = Server.getUserList();
		ArrayList<User> diskUsers;
		diskUsers = Server.loadFromDisk();
		assert serverUsers.size()==diskUsers.size();
		for(int i=0;i<diskUsers.size();i++)
		{
			assertTrue(diskUsers.get(i).equals(serverUsers.get(i)));
		}
		//assertTrue(u.equals(diskUsers));
		
	}

}
