package Rello;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserTest
{
	User gus;
	User josh;

	@BeforeEach
	void setUp() throws Exception
	{
		gus = new User("gus","crow");
		josh = new User("josh","west");
	}

	@Test
	void testCreateBoard()
	{
		gus.createBoard("board1");
		assertEquals("board1",gus.Boards.get("board1").Name);
		assert gus.Boards.get("board1").Owner.userEquals(gus);
		assert gus.Boards.get("board1").Owner.userEquals(josh)==false;

	}

	@Test
	void testEqualsUser()
	{
		assert gus.userEquals(josh)==false;
		assert gus.userEquals(gus);
	}
}
