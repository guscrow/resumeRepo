package Rello;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CardTest
{
	User gus;
	User josh;
	User testUser;
	Board board;
	List list;
	Card card;
	
	@BeforeEach
	void setUp() throws Exception
	{
		gus = new User("gus","crow");
		josh = new User("josh","west");
		testUser = new User("test","user");
		board = new Board("board1",gus);
		board.addMember(josh, gus);
		list = new List("list1",board);
		card = new Card("card1",board);
		list.addCard(card);	
	}

	@Test
	void testAddMember()
	{
		assert card.Members.size()==0;
		card.addMember(josh);
		assert card.Members.size()==1;
		card.addMember(testUser);
		assert card.Members.size()==1;
	}

	@Test
	void testRemoveMember()
	{
		assert card.Members.size()==0;
		card.addMember(josh);
		assert card.Members.size()==1;
		card.removeMember(0);
		assert card.Members.size()==0;
	}

	@Test
	void testAddComponent()
	{
		Description desc = new Description("test");
		assert card.Components.size()==0;
		card.addComponent(desc);
		assert card.Components.size()==1;
	}

	@Test
	void testRemoveComponent()
	{
		Description desc = new Description("test");
		assert card.Components.size()==0;
		card.addComponent(desc);
		assert card.Components.size()==1;
		card.removeComponent(0);
		assert card.Components.size()==0;
	}

	@Test
	void testAddLabel()
	{
		Label label = new Label(Colors.GREEN,"test");
		assert card.Labels.size()==0;
		card.addLabel(Colors.GREEN,label);
		assert card.Labels.size()==1;
	}

	@Test
	void testRemoveLabel()
	{
		Label label = new Label(Colors.GREEN,"test");
		assert card.Labels.size()==0;
		card.addLabel(Colors.GREEN,label);
		assert card.Labels.size()==1;
		card.removeLabel(Colors.GREEN);
		assert card.Labels.size()==0;
	}

}
