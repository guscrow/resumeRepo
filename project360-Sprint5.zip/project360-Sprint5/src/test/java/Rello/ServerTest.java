package Rello;

import java.rmi.registry.Registry;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class ServerTest
{
	static Server sv;
	static Registry registry;
	static Client client;
	static String bindName = "RELLO";
	@BeforeAll
	static void setUp() throws Exception
	{
		sv = new Server();
		registry = sv.bootServer(bindName);
		client = new Client(registry,bindName);
	}


	@Test
	void testLogin()
	{
		assert client.loginUser("gus", "crow");
		assert client.loginUser("ASDFB", "ASD  GBFB")==false;
	}

	@Test 
	void testCreateBoard()
	{
		client.loginUser("gus", "crow");
		client.getMe().getBoards().clear();
		assert client.getMe().getBoards().size()==0;
		client.createBoard("testServerBoard", client.getMe());
		assert client.getMe().getBoards().size()==1;
		client.getMe().getBoards().clear();
	}
	
	@Test
	void testSetName()
	{
		client.loginUser("gus", "crow");
		client.createBoard("testServerBoard", client.getMe());
		Board meBoard = client.getMe().getBoard("testServerBoard");
		meBoard.setName("ChangedName", client.getMe());
		client.updateBoard(client.getMe(), meBoard);
		Board updatedBoard = client.getMe().getBoard("ChangedName");
		assert updatedBoard.getBoard_id()==meBoard.getBoard_id();
		client.getMe().getBoards().clear();
	}
	
	@Test
	void testUpdateBoard()
	{
		client.loginUser("gus", "crow");
		client.createBoard("testServerBoard", client.getMe());
		Board meBoard = client.getMe().getBoard("testServerBoard");
		User test = new User("test","user");
		assert meBoard.getMembers().size()==0;
		meBoard.addMember(test, client.getMe());
		assert meBoard.getMembers().size()==1;
		client.updateBoard(client.getMe(), meBoard);
		Board updatedBoard = client.getMe().getBoard("testServerBoard");
		assert updatedBoard.getBoard_id()==meBoard.getBoard_id();
		assert meBoard.getMembers().size()==updatedBoard.getMembers().size();
		assert meBoard.getMembers().get("test").equals(updatedBoard.getMembers().get("test"));
		client.getMe().getBoards().clear();
	}
	
	@AfterAll
	static void tearDown() throws Exception
	{
		//System.out.println("Closing server");

		sv.closeServer(registry);
	}
}
