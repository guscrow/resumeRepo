package Rello;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BoardTest
{
	User gus;
	User josh;
	User testuser;
	Board board;
	
	@BeforeEach
	void setUp() throws Exception
	{
		gus = new User("gus","crow");
		josh = new User("josh","west");
		testuser = new User("test","user");
		board = new Board("board1",gus);
	}

	
	@Test
	void testAddMember()
	{
		board.addMember(josh, gus);
		assert board.Members.size()==1;
		board.addMember(testuser, josh);
		assert board.Members.size()==1;
		board.addMember(testuser, gus);
		assert board.Members.size()==2;
		assert board.Members.get("josh").userEquals(josh);
	}
	
	@Test
	void testVerifyUser()
	{
		board.addMember(josh, gus);
		assert board.verifyUser(josh): board.verifyUser(josh);
		assert board.verifyUser(gus)==false;
	}


	@Test
	void testRemoveMember()
	{
		board.addMember(josh, gus);
		assert board.Members.size()==1;
		board.removeMember(josh, josh);
		assert board.Members.size()==1;
		board.removeMember(josh, gus);
		assert board.Members.size()==0;
	}

	@Test
	void testAddList()
	{
		List list = new List("list1",board);
		board.addList(list);
		assert board.Lists.size()==1;
	}

	@Test
	void testRemoveList()
	{
		List list = new List("list1",board);
		board.addList(list);
		assert board.Lists.size()==1;
		board.removeList(list);
		assert board.Lists.size()==0;
	}

	@Test
	void testMoveList()
	{
		List list = new List("list1",board);
		List list2 = new List("list2",board);
		List list3 = new List("list3",board);
		List list4 = new List("list4",board);
		List list5 = new List("list5",board);

		board.addList(list);
		board.addList(list2);
		board.addList(list3);
		board.addList(list4);
		board.addList(list5);

		assert board.Lists.get(0).Name=="list1";
		board.moveList(0, 3);
		assert board.Lists.get(0).Name=="list2";
		assert board.Lists.get(3).Name=="list1";

	}

}
