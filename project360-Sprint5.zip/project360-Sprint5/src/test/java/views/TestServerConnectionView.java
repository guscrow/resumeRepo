package views;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.testfx.api.FxRobot;
import org.testfx.framework.junit5.ApplicationExtension;
import org.testfx.framework.junit5.Start;

import Rello.Board;
import Rello.Client;
import Rello.Server;

import org.testfx.assertions.api.Assertions;


import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;



@ExtendWith(ApplicationExtension.class)
public class TestServerConnectionView
{
	ServerViewController cont; 
	public static Server sv;
	public static Registry registry;
	public static Client client;
	static String bindName = "RELLO";
	Stage primaryStage;
	
	@BeforeAll
	static void setUp() throws Exception
	{
		sv = new Server();
		registry = LocateRegistry.createRegistry(1099);
		registry.rebind("RELLO",sv);
		Server.setUserList(Server.loadFromDisk("Sprint4Data.xml"));
		for(int i = 0; i<Server.userList.size(); i++)
		{
			sv.loadBoards(Server.userList.get(i));
		}
	}
	
	@Start
	private void start(Stage primaryStage)
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Board.class.getResource("../views/ServerView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			cont = loader.getController();
			cont.setStage(primaryStage);
			Scene s = new Scene(view);
			primaryStage.setScene(s);
			primaryStage.show();
			
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void testDefault(FxRobot robot) throws MalformedURLException
	{
		try
		{
			Thread.sleep(1000);
			robot.clickOn("#defaultButton");
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
//	@Test
//	public void testEnterIP(FxRobot robot) throws MalformedURLException
//	{
//		robot.clickOn("#IPtextbox");
//		robot.write("rmi://127.0.0.1/RELLO");
//		robot.clickOn("#EnterIPButton");
//	}
//	
	@AfterAll
	static void tearDown() throws Exception
	{
		//System.out.println("Closing server");

		registry.unbind("RELLO");
	}
}
