package views;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.testfx.api.FxRobot;
import org.testfx.framework.junit5.ApplicationExtension;
import org.testfx.framework.junit5.Start;

import Rello.Board;
import Rello.Client;
import Rello.List;
import Rello.Server;
import Rello.User;

import org.testfx.assertions.api.Assertions;


import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;



@ExtendWith(ApplicationExtension.class)
public class listCreateViewTest
{
	listCreateViewController cont; 
	public static Server sv;
	public static Registry registry;
	public static Client client;
	static String bindName = "RELLO";
	Stage primaryStage;
	Board board;
	
	@BeforeAll
	static void setUp() throws Exception
	{
		sv = new Server();
		registry = LocateRegistry.createRegistry(1099);
		registry.rebind("RELLO",sv);
		Server.setUserList(Server.loadFromDisk("Sprint4Data.xml"));
		for(int i = 0; i<Server.userList.size(); i++)
		{
			sv.loadBoards(Server.userList.get(i));
		}
		client = new Client("rmi://localhost/RELLO");
		client.loginUser("gus", "crow");
		
	}
	
	@Start
	private void start(Stage primaryStage)
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Board.class.getResource("../views/listCreateView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			cont = loader.getController();
			board = client.getMe().getBoard("testboard");
			cont.setModel(board);
			cont.setClient(client);
			cont.setStage(primaryStage);
			Scene s = new Scene(view);
			primaryStage.setScene(s);
			primaryStage.show();
			
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testList(FxRobot robot) throws MalformedURLException
	{
		robot.clickOn("#listNameTB");
		robot.write("extraList");
		robot.clickOn("#createButton");
		
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<List> Lists = board.getLists();
		List list = Lists.get(0);
		BorderPane listView = robot.lookup("#extraList").queryAs(BorderPane.class);
		Button moveLeftButton = (Button) robot.lookup("#extraList").queryAs(BorderPane.class).lookup("#moveLeftButton");
		robot.clickOn(moveLeftButton);
		Lists = board.getLists();
		assert Lists.indexOf(list)==1;

		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Button moveRightButton = (Button) robot.lookup("#extraList").queryAs(BorderPane.class).lookup("#moveRightButton");
		robot.clickOn(moveRightButton);
		Lists = board.getLists();
		assert Lists.indexOf(list)==0;
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
//	@Test
//	public void testCancel(FxRobot robot) throws MalformedURLException
//	{
//		robot.clickOn("#cancelButton");
//	}
	
	@AfterAll
	static void tearDown() throws Exception
	{
		//System.out.println("Closing server");

		registry.unbind("RELLO");
	}
}
