package views;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.testfx.api.FxRobot;
import org.testfx.framework.junit5.ApplicationExtension;
import org.testfx.framework.junit5.Start;

import Rello.Board;
import Rello.Card;
import Rello.Client;
import Rello.List;
import Rello.Server;
import Rello.User;

import org.testfx.assertions.api.Assertions;


import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



@ExtendWith(ApplicationExtension.class)
public class boardViewTest
{
	boardViewController cont; 
	public static Server sv;
	public static Registry registry;
	public static Client client;
	static String bindName = "RELLO";
	Stage primaryStage;
	
	@BeforeAll
	static void setUp() throws Exception
	{
		sv = new Server();
		registry = LocateRegistry.createRegistry(1099);
		registry.rebind("RELLO",sv);
		Server.setUserList(Server.loadFromDisk("Sprint4Data.xml"));
		for(int i = 0; i<Server.userList.size(); i++)
		{
			sv.loadBoards(Server.userList.get(i));
		}
		client = new Client("rmi://localhost/RELLO");
		client.loginUser("gus", "crow");
	}
	
	@Start
	private void start(Stage primaryStage)
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Board.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			cont = loader.getController();
			cont.setModel(client);
			cont.setStage(primaryStage);
			cont.setBoard(client.getMe().getBoard("testboard"));
			Scene s = new Scene(view);
			primaryStage.setScene(s);
			primaryStage.show();
			
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testLists(FxRobot robot) throws MalformedURLException
	{
		ArrayList<List> Lists = client.getMe().getBoard("testboard").getLists();
		HBox ListPane = robot.lookup("#boardStorageBox").queryAs(HBox.class);
		for (List list: Lists)
		{
			String listName = list.getName();
			String selector = "#"+listName;
			Assertions.assertThat(ListPane.lookup(selector)).isNotEqualTo(null);
		}
	}
	
	@Test
	public void testCard(FxRobot robot) throws MalformedURLException
	{
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		robot.clickOn("#addNewCardButton");
		robot.clickOn("#cardNameTB");
		robot.write("testCard");
		robot.clickOn("#createButton");
		VBox cardListPane = robot.lookup("#cardStorageBox").queryAs(VBox.class);
		Board board = client.getMe().getBoard("testboard");
		ArrayList<List>Lists = board.getLists();
		List list = Lists.get(0);
		for (Card card: list.getCards())
		{
			String cardName = card.getName();
			String selector = "#"+cardName;
			Assertions.assertThat(cardListPane.lookup(selector)).isNotEqualTo(null);
		}
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		robot.clickOn("#testCard");
		TextField cardName = robot.lookup("#cardNameTB").queryAs(TextField.class);
		assert cardName.getText().equals("testCard");
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		robot.clickOn("#descBox");
		robot.write("test description");
		robot.clickOn("#saveButton");
		
		robot.clickOn("#testCard");
		TextArea desc = robot.lookup("#descBox").queryAs(TextArea.class);
		assert desc.getText().equals("test description");
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		robot.clickOn("#cardNameTB");
		robot.write("1");
		robot.clickOn("#saveButton");
		robot.clickOn("#test1Card");
		cardName = robot.lookup("#cardNameTB").queryAs(TextField.class);
		assert cardName.getText().equals("test1Card");
		robot.clickOn("#removeButton");
		assert cardListPane.getChildren().size()==1;
		
		robot.clickOn("#addNewCardButton");
		robot.clickOn("#cardNameTB");
		robot.write("testCard");
		robot.clickOn("#createButton");
		
		robot.clickOn("#addNewCardButton");
		robot.clickOn("#cardNameTB");
		robot.write("testCard2");
		robot.clickOn("#createButton");
		
		Lists = client.getMe().getBoard("testboard").getLists();
		list = Lists.get(0);
		ArrayList<Card> Cards = list.getCards();
		Card card = Cards.get(0);
		assert Cards.indexOf(card)==0;
		Button cardButton = (Button) robot.lookup("#testList").queryAs(BorderPane.class).lookup("#testCard2");
		robot.clickOn(cardButton);
		robot.clickOn("#moveUpButton");
		assert Cards.indexOf(card)==1;
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		cardButton = (Button) robot.lookup("#testList").queryAs(BorderPane.class).lookup("#testCard2");
		robot.clickOn(cardButton);
		robot.clickOn("#moveDownButton");
		assert Cards.indexOf(card)==0;
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		robot.clickOn("#editButton");
		robot.clickOn("#removeButton");
		HBox ListPane = robot.lookup("#boardStorageBox").queryAs(HBox.class);
		assert ListPane.getChildren().size()==1;
	}
	
	@AfterAll
	static void tearDown() throws Exception
	{
		//System.out.println("Closing server");

		registry.unbind("RELLO");
	}
}
