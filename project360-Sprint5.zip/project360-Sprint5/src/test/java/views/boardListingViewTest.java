package views;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.HashMap;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.testfx.api.FxRobot;
import org.testfx.framework.junit5.ApplicationExtension;
import org.testfx.framework.junit5.Start;

import Rello.Board;
import Rello.Client;
import Rello.Server;
import Rello.User;

import org.testfx.assertions.api.Assertions;


import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;



@ExtendWith(ApplicationExtension.class)
public class boardListingViewTest
{
	boardListingViewController cont; 
	public static Server sv;
	public static Registry registry;
	public static Client client;
	static String bindName = "RELLO";
	Stage primaryStage;
	
	@BeforeAll
	static void setUp() throws Exception
	{
		sv = new Server();
		registry = LocateRegistry.createRegistry(1099);
		registry.rebind("RELLO",sv);
		Server.setUserList(Server.loadFromDisk("Sprint4Data.xml"));
		for(int i = 0; i<Server.userList.size(); i++)
		{
			sv.loadBoards(Server.userList.get(i));
		}
		client = new Client("rmi://localhost/RELLO");
		client.loginUser("gus", "crow");
	}
	
	@Start
	private void start(Stage primaryStage)
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Board.class.getResource("../views/boardListingView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			cont = loader.getController();
			cont.setModel(client.getMe());
			cont.setClient(client);
			cont.setStage(primaryStage);
			Scene s = new Scene(view);
			primaryStage.setScene(s);
			primaryStage.show();
			
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testBoards(FxRobot robot) throws MalformedURLException
	{
		HashMap<String, Board> Boards = client.getMe().getBoards();
		FlowPane boardListPane = robot.lookup("#boardsPane").queryAs(FlowPane.class);
		for (Board board: Boards.values())
		{
			String boardName = board.getName();
			String selector = "#"+boardName;
			Assertions.assertThat(boardListPane.lookup(selector)).isNotEqualTo(null);
		}
	}
	
//	@Test
//	public void clickAddBoard(FxRobot robot) throws MalformedURLException
//	{
//		robot.clickOn("#addBoardButton");
//	}
	
//	@Test
//	public void clickTestLogout(FxRobot robot) throws MalformedURLException
//	{
//		robot.clickOn("#logoutButton");
//	}
	
	@Test
	public void clickBoard(FxRobot robot) throws MalformedURLException
	{
		robot.clickOn("#testboard");
		try
		{
			Thread.sleep(1000);
			TextField boardName = robot.lookup("#boardNameTB").queryAs(TextField.class);
			assert boardName.getText().equals("testboard");
			robot.clickOn("#boardNameTB");
			robot.write("1");
			robot.clickOn("#backButton");
			Thread.sleep(1000);
			robot.clickOn("#testboa1rd");
			boardName = robot.lookup("#boardNameTB").queryAs(TextField.class);
			assert boardName.getText().equals("testboa1rd");
			HBox ListsBox = robot.lookup("#boardStorageBox").queryAs(HBox.class);
			BorderPane listView = robot.lookup("#testList").queryAs(BorderPane.class);
			robot.clickOn("#listNameTB");
			robot.write("1");
			robot.clickOn("#saveButton");
			robot.clickOn("#backButton");
			Thread.sleep(1000);
			robot.clickOn("#testboa1rd");
			assert robot.lookup("#listNameTB").queryAs(TextField.class).getText().equals("testList1");
			Thread.sleep(1000);
			
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	@AfterAll
	static void tearDown() throws Exception
	{
		//System.out.println("Closing server");

		registry.unbind("RELLO");
	}
}
