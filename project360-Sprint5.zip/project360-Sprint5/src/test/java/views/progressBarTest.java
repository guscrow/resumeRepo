package views;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.testfx.api.FxRobot;
import org.testfx.framework.junit5.ApplicationExtension;
import org.testfx.framework.junit5.Start;

import Rello.Board;
import Rello.Card;
import Rello.Client;
import Rello.List;
import Rello.Server;
import Rello.User;

import org.testfx.assertions.api.Assertions;


import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



@ExtendWith(ApplicationExtension.class)
public class progressBarTest
{
	boardViewController cont; 
	public static Server sv;
	public static Registry registry;
	public static Client client;
	static String bindName = "RELLO";
	Stage primaryStage;
	
	@BeforeAll
	static void setUp() throws Exception
	{
		sv = new Server();
		registry = LocateRegistry.createRegistry(1099);
		registry.rebind("RELLO",sv);
		Server.setUserList(Server.loadFromDisk("Sprint4Data.xml"));
		for(int i = 0; i<Server.userList.size(); i++)
		{
			sv.loadBoards(Server.userList.get(i));
		}
		client = new Client("rmi://localhost/RELLO");
		client.loginUser("gus", "crow");
	}
	
	@Start
	private void start(Stage primaryStage)
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Board.class.getResource("../views/boardView.fxml"));
		BorderPane view;
		try
		{
			view = loader.load();
			cont = loader.getController();
			System.out.println(client);
			cont.setModel(client);
			cont.setStage(primaryStage);
			cont.setBoard(client.getMe().getBoard("testboard"));
			Scene s = new Scene(view);
			primaryStage.setScene(s);
			primaryStage.show();
			
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testProgressBar(FxRobot robot) throws MalformedURLException
	{
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		robot.clickOn("#addNewCardButton");
		robot.clickOn("#cardNameTB");
		robot.write("testCard");
		robot.clickOn("#createButton");
		
		robot.clickOn("#addNewCardButton");
		robot.clickOn("#cardNameTB");
		robot.write("testCard2");
		robot.clickOn("#createButton");
		
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		robot.clickOn("#testCard2");
		robot.clickOn("#compCheckBox");
		robot.clickOn("#saveButton");
		
		robot.clickOn("#viewProgressButton");
		
		ProgressBar pb = robot.lookup("#progressBar").queryAs(ProgressBar.class);
		assert pb.getProgress()==0.5;
		
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		
		robot.clickOn("#backButton");
		
		robot.clickOn("#addNewCardButton");
		robot.clickOn("#cardNameTB");
		robot.write("testCard3");
		robot.clickOn("#createButton");
		
		robot.clickOn("#viewProgressButton");
		
		pb = robot.lookup("#progressBar").queryAs(ProgressBar.class);
		assert pb.getProgress()==0.3333333333333333;
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	
		robot.clickOn("#backButton");
		
		robot.clickOn("#testCard3");
		robot.clickOn("#removeButton");
		
		robot.clickOn("#viewProgressButton");
		
		pb = robot.lookup("#progressBar").queryAs(ProgressBar.class);
		assert pb.getProgress()==0.5;
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		robot.clickOn("#backButton");
		
		robot.clickOn("#testCard2");
		robot.clickOn("#compCheckBox");
		robot.clickOn("#saveButton");

		robot.clickOn("#viewProgressButton");
		
		pb = robot.lookup("#progressBar").queryAs(ProgressBar.class);
		assert pb.getProgress()==0.0;
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		robot.clickOn("#backButton");
		robot.clickOn("#addNewListButton");
		robot.clickOn("#listNameTB");
		robot.write("extraList");
		robot.clickOn("#createButton");
		
		
		BorderPane extraList = robot.lookup("#extraList").queryAs(BorderPane.class);
		//System.out.println(extraList);
		Button addCardButton = (Button) extraList.lookup("#addNewCardButton");
		robot.clickOn(addCardButton);
		
		robot.clickOn("#cardNameTB");
		robot.write("list2TestCard");
		robot.clickOn("#createButton");
		
		extraList = robot.lookup("#extraList").queryAs(BorderPane.class);
		addCardButton = (Button) extraList.lookup("#addNewCardButton");
		
		robot.clickOn(addCardButton);
		
		robot.clickOn("#cardNameTB");
		robot.write("list2TestCard2");
		robot.clickOn("#createButton");
		
		robot.clickOn("#testCard2");
		robot.clickOn("#compCheckBox");
		robot.clickOn("#saveButton");
		
		robot.clickOn("#viewProgressButton");
		
		pb = robot.lookup("#progressBar").queryAs(ProgressBar.class);
		assert pb.getProgress()==0.25;
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		robot.clickOn("#backButton");
		robot.clickOn("#list2TestCard");
		robot.clickOn("#compCheckBox");
		robot.clickOn("#saveButton");
		
		robot.clickOn("#viewProgressButton");
		
		pb = robot.lookup("#progressBar").queryAs(ProgressBar.class);
		assert pb.getProgress()==0.5;
		
		try
		{
			Thread.sleep(1000);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		robot.clickOn("#backButton");
		
	}
	
	@AfterAll
	static void tearDown() throws Exception
	{
		//System.out.println("Closing server");

		registry.unbind("RELLO");
	}
}
