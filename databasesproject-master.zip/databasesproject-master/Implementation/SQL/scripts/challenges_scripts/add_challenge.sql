/*  This can be used to create a record in the "challenges" table
*   For a prepared statement, the following values should be used:
*   'i,i'
*/

INSERT INTO challenges (challenge_id,trainer_id) VALUES (?,?);