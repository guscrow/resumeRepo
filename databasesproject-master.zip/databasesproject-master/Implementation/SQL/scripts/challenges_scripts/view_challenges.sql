/*View all of the challenges made*/

SELECT * FROM challenges;