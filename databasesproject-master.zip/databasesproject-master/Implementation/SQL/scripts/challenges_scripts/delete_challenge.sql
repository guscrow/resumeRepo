This can be used to delete a record from the "challenges" table
*   For a prepared statement, the following value should be used:
*   'i'

DELETE FROM challenges WHERE challenge_id = ?;