/*  This can be used to create a record in the "pokemonused_for_challenges" table
*   For a prepared statement, the following values should be used:
*   'i,i,i'
*/

INSERT INTO pokemon_used_for_challenges (pokemon_challenge_id, pokemon_id. challenge_id)
VALUES (?, ?, ?);
