/*  This can be used to view all records from the "items_used" table
*   For a prepared statement, the following values should be used:
*   N/A
*/

SELECT * FROM items_used;