/*used to delete a record from "hall_of_fame" table
syntax for prepared statement should be:
i
*/

DELETE FROM hall_of_fame WHERE hof_id = ?;