/*used to select a specific hall of fame record
syntax for prepared statement should be:
i
*/
SELECT * FROM hall_of_fame WHERE hof_id = ?;