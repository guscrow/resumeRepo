/*Used to update a record in the "hall_of_fame" table
syntax should be like:
i,i,i
*/

UPDATE hall_of_fame SET trainer_id = ? SET pokemon_id = ?
WHERE hof_id = ?;