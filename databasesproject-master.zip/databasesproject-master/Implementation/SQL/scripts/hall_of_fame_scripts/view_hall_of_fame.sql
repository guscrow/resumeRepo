/*Used to access all hall of fame records*/

SELECT * FROM hall_of_fame;